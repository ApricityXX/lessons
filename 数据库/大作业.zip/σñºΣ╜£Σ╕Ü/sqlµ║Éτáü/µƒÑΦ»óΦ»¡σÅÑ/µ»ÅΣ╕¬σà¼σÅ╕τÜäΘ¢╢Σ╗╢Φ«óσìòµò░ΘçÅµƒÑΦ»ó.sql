SELECT c.公司_name, COUNT(o.零件_ordno) AS 订单总数
FROM 公司 c, 零件订单 o, 零件 p
WHERE c.公司_ID = o.公司_ID
  AND o.零件_ID = p.零件_ID
GROUP BY c.公司_name
ORDER BY 订单总数 DESC;
