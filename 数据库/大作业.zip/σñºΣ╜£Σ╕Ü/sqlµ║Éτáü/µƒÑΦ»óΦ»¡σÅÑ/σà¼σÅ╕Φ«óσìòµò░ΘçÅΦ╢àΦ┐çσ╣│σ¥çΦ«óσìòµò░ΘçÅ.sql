SELECT c.公司_name, COUNT(o.零件_ordno) AS 订单总数
FROM 公司 c, 零件订单 o, 供应商 s
WHERE c.公司_ID = o.公司_ID
  AND o.供应商_ID = s.供应商_ID
  AND c.公司_city <> s.供应商_city
GROUP BY c.公司_name
HAVING COUNT(o.零件_ordno) > (SELECT AVG(订单总数) FROM (SELECT COUNT(零件_ordno) AS 订单总数 FROM 零件订单 GROUP BY 公司_ID) AS avg_orders)
ORDER BY 订单总数 DESC;
