SELECT
    顾客.address,
    COUNT(车辆条目.order_quantity) AS 购买数量,
    AVG(车辆订单.total_price) AS 平均价格
FROM
    顾客,
    车辆订单,
    车辆条目
WHERE
    顾客.CID = 车辆订单.CID
    AND 车辆订单.订单_ordno = 车辆条目.订单_ordno
GROUP BY
    顾客.address
HAVING
    COUNT(车辆条目.order_quantity) >= 3
ORDER BY
    平均价格 DESC
