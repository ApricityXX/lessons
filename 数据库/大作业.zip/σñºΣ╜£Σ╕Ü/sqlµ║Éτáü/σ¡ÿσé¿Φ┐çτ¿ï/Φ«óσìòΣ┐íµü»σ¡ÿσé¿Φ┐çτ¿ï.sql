CREATE PROCEDURE sp_get_order_details
    @order_ordno INT
AS
BEGIN
    SELECT o.*, c.*, d.*
    FROM [车辆订单] o
    JOIN [顾客] c ON o.[CID] = c.[CID]
    JOIN [经销商] d ON o.[经销商_ID] = d.[经销商_ID]
    WHERE o.[订单_ordno] = @order_ordno;
END;
