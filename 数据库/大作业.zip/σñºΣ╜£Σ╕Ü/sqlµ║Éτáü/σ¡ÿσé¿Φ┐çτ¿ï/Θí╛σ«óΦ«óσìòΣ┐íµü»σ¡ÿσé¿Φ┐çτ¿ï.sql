CREATE PROCEDURE sp_get_customer_orders
    @customer_id INT
AS
BEGIN
    SELECT o.*, d.*
    FROM [车辆订单] o
    JOIN [经销商] d ON o.[经销商_ID] = d.[经销商_ID]
    WHERE o.[CID] = @customer_id;
END;

