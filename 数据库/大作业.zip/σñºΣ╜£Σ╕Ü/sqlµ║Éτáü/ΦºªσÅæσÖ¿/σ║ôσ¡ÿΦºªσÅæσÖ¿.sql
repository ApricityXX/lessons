USE [Cars]
GO

/****** Object: Trigger [dbo].[update_inventory] ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER TRIGGER [dbo].[update_inventory]
ON [dbo].[车辆条目]
AFTER INSERT, UPDATE
AS
BEGIN
    -- 更新库存数量
    UPDATE 库存
    SET 数量 = 100 - inserted.order_quantity
    FROM 库存
    INNER JOIN 车辆 ON 库存.库存_ID = 车辆.库存_ID
    INNER JOIN 车辆条目 ON 车辆.VIN = 车辆条目.VIN
    INNER JOIN 车辆订单 ON 车辆订单.订单_ordno = 车辆条目.订单_ordno
    INNER JOIN inserted ON 车辆条目.VIN = inserted.VIN
END;
