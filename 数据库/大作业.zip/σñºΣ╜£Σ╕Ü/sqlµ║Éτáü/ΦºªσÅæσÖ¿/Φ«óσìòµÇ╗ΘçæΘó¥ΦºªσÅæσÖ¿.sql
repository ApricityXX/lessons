CREATE TRIGGER trg_calculate_total_price
ON [车辆订单]
AFTER INSERT, UPDATE
AS
BEGIN
    -- 更新新增或修改的行的total_price值
    UPDATE o
    SET o.total_price = c.price * oi.order_quantity
    FROM [车辆订单] o
    JOIN inserted i ON o.[订单_ordno] = i.[订单_ordno]
    JOIN [订单条目] oi ON o.[订单_ordno] = oi.[订单_ordno]
    JOIN [车辆] v ON oi.VIN = v.VIN
    JOIN [车型] c ON v.[车型_ID] = c.[车型_ID]
END;