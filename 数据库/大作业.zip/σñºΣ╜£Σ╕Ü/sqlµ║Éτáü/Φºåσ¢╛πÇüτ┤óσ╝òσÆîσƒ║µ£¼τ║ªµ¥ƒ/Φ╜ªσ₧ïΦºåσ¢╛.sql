CREATE VIEW 车型_View AS
SELECT 车辆.VIN, 车辆.color, 车辆.engine, 车辆.gearbox, 车型.车型_name
FROM 车辆
JOIN 车型 ON 车辆.车型_ID = 车型.车型_ID;
