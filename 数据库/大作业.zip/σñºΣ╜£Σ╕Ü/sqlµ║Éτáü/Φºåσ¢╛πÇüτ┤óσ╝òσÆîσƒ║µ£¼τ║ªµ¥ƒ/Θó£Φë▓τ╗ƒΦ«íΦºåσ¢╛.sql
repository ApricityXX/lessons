CREATE VIEW 颜色统计_View AS
SELECT color, COUNT(*) AS 车辆数量
FROM 车辆
GROUP BY color;
