ALTER TABLE �˿�
ADD CONSTRAINT CK_IncomeNonNegative CHECK (annual_income >= 0);
