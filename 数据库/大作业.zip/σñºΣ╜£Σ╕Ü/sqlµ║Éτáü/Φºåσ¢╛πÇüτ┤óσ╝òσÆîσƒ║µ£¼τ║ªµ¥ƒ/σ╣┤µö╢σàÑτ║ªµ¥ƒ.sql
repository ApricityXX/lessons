ALTER TABLE 顾客
ADD CONSTRAINT CK_IncomeNonNegative CHECK (annual_income >= 0);
