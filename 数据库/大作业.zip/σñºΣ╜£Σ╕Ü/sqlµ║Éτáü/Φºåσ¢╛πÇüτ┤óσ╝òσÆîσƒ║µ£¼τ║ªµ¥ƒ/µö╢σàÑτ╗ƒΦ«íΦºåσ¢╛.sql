CREATE VIEW 顾客收入统计_View AS
SELECT 顾客.CID, 顾客.cname, 顾客.annual_income
FROM 顾客;
