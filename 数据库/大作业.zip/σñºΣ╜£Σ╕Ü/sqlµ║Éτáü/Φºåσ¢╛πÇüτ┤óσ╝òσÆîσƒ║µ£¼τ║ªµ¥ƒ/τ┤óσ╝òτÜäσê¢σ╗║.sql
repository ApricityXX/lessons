
CREATE INDEX idx_vehicle_model ON [车辆] ([车型_ID]);


CREATE INDEX idx_customer_id ON [顾客] ([CID]);


CREATE INDEX idx_order_orderno ON [车辆订单] ([订单_ordno]);
