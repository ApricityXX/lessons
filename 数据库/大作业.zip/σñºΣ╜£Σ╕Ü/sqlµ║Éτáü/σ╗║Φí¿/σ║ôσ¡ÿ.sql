/****** Object:  Table [dbo].[库存]    Script Date: 2023/6/17 1:42:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[库存](
	[库存_ID] [int] NOT NULL,
	[库存_name] [varchar](100) NULL,
	[库存_city] [varchar](100) NULL,
	[经销商_ID] [int] NULL,
	[数量] [int] NULL,
 CONSTRAINT [库存_pk] PRIMARY KEY CLUSTERED 
(
	[库存_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO