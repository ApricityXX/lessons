import random
class Account:
    rate = 0.04

    def __init__(self, username, id_number, password, balance):
        self.username = username
        self.id_number = id_number
        self.password = password
        self.balance = balance
#利率
    def show_lilv(self):

        print(f"目前的利率：{Account.rate}")
#密码
    def change_pd(self, new_pd):
        self.password = new_pd
        print("密码已成功修改")
        print(f"新密码为：{new_pd}")
#单号
    def id(self):
        a=[]
        id = random.randint(1000000, 9999999)
        while(1):
            if id in a:
                id = random.randint(1000000, 9999999)
            else:
                break
        a.append(id)
        print(f"订单号为：{id}")
#存款
    def save(self, num):
        self.balance += num
        if self.balance >= 1000000:
            Account.rate += 0.02
#检查 存款大于50w
    def check(self):
        if self.balance >= 500000:
            print("您符合分期付款的条件")
        else:
            print("抱歉，您的存款不满足最低余额要求，无法分期付款")
#显示存款
    def show_total(self):
        print(f"目前的总存款为：{self.balance}")


A = Account("薛凡豪","1",20211120138,1000000)
A.save(100000)
print(A.id())
A.show_total()
A.show_lilv()
A.check()
A.change_pd(123456789)